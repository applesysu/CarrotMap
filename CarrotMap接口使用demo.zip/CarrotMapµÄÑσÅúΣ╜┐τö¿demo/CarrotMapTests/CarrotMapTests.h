//
//  CarrotMapTests.h
//  CarrotMapTests
//
//  Created by Jacob Pan on 12-11-5.
//  Copyright (c) 2012年 sysuAppleClub. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CarrotMapTests : SenTestCase

@end
