//
//  ACTestViewController.h
//  CarrotMap
//
//  Created by Jacob Pan on 12-11-9.
//  Copyright (c) 2012年 sysuAppleClub. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACTestViewController : UIViewController

@property (nonatomic, strong) UITextView *textView;

@end
