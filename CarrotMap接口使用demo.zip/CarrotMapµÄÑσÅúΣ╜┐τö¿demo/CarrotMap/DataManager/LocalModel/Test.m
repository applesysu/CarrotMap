//
//  Test.m
//  CarrotMap
//
//  Created by Jacob Pan on 12-11-9.
//  Copyright (c) 2012年 sysuAppleClub. All rights reserved.
//

#import "Test.h"


@implementation Test

@dynamic name;

@end
