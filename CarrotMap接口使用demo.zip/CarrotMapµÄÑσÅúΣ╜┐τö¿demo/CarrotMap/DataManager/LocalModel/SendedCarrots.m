//
//  SendedCarrots.m
//  CarrotMap
//
//  Created by Jacob Pan on 12-11-9.
//  Copyright (c) 2012年 sysuAppleClub. All rights reserved.
//

#import "SendedCarrots.h"


@implementation SendedCarrots

@dynamic carrotID;
@dynamic image;
@dynamic isPublic;
@dynamic latitude;
@dynamic longitude;
@dynamic message;
@dynamic receiversID;
@dynamic sendedTime;
@dynamic senderID;
@dynamic video;
@dynamic vioce;

@end
