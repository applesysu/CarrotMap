//
//  ReceivedCarrots.m
//  CarrotMap
//
//  Created by Jacob Pan on 12-11-9.
//  Copyright (c) 2012年 sysuAppleClub. All rights reserved.
//

#import "ReceivedCarrots.h"


@implementation ReceivedCarrots

@dynamic carrotID;
@dynamic image;
@dynamic isPublic;
@dynamic latitude;
@dynamic longitude;
@dynamic message;
@dynamic receiverID;
@dynamic receiversID;
@dynamic sendedTime;
@dynamic senderID;
@dynamic video;
@dynamic vioce;

@end
