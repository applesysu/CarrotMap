//
//  ACAddCarrotViewController.h
//  CarrotMap
//
//  Created by Jacob Pan on 12-11-5.
//  Copyright (c) 2012年 sysuAppleClub. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACFriendsListViewController.h"

@interface ACAddCarrotViewController : UIViewController

@property (nonatomic, strong) ACFriendsListViewController *friendsListViewController;

@end
