//
//  ACRootViewController.h
//  CarrotMap
//
//  Created by Jacob Pan on 12-11-5.
//  Copyright (c) 2012年 sysuAppleClub. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACLoginViewController.h"
#import "ACMapViewController.h"
#import "ACNewCarrotsListViewController.h"
#import "ACMyViewViewController.h"

@interface ACRootViewController : UIViewController

@property (nonatomic, strong) ACLoginViewController *loginViewController;
@property (nonatomic, strong) ACMapViewController *mapViewController;
@property (nonatomic, strong) ACNewCarrotsListViewController *carrotsListViewController;
@property (nonatomic, strong) ACMyViewViewController *myViewViewController;

@end
