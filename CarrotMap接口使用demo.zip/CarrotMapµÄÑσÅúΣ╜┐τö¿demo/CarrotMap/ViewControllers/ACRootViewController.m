//
//  ACRootViewController.m
//  CarrotMap
//
//  Created by Jacob Pan on 12-11-5.
//  Copyright (c) 2012年 sysuAppleClub. All rights reserved.
//

#import "ACRootViewController.h"
#import "JPDataManager.h"

@interface ACRootViewController ()

@end

@implementation ACRootViewController

@synthesize loginViewController;
@synthesize mapViewController;
@synthesize carrotsListViewController;
@synthesize myViewViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btn setTitle:@"登录人人" forState:UIControlStateNormal];
    [btn setFrame:CGRectMake(20, 20, 120, 40)];
    [btn addTarget:self action:@selector(btn1Pressed) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void) btn1Pressed
{
    NSLog(@"Button 1 Pressed");
    
    //监听特定通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRenrenLogin) name:@"didRenrenLogin" object:nil];
    
    [[JPDataManager sharedInstance] RenrenLogin];
}

@end
